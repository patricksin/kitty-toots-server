# Kitty Toots: your own hosting

- `site/index.html`: the whole game in one file. Upload it to Netlify.
- `worker/`: the multiplayer and voice chat server, a Cloudflare Worker.

Without the Worker the game still runs, as a one-player game.

## 1. Deploy the Worker

```
cd worker
npm install
npx wrangler login
npx wrangler deploy
```

Wrangler prints an address like `https://kitty-toots.your-name.workers.dev`.
Open it in a browser and you should see "Kitty Toots server is running."

## 2. Turn on TURN for voice chat

Voice goes straight from one player's browser to another. Some home, school and
phone networks block that. TURN relays the audio when that happens.

1. In the Cloudflare dashboard, go to **Realtime > TURN Server** and create a TURN app.
2. Copy the **Turn Key ID** and the **API Token**. Cloudflare only shows the token once.
3. Store them as secrets on the Worker:

```
npx wrangler secret put TURN_KEY_ID
npx wrangler secret put TURN_KEY_API_TOKEN
```

The Worker turns these into short-lived TURN logins, each lasting 4 hours.
Your key never reaches the browser. To change the lifetime, set `TURN_TTL` in
`wrangler.toml`.

If you run your own coturn server instead:

1. In `wrangler.toml` under `[vars]`, set `TURN_URLS`, for example
   `turn:turn.example.com:3478`.
2. Run `npx wrangler secret put TURN_SECRET` with your coturn `static-auth-secret`.

## 3. Point the game at the Worker and publish it

1. Near the top of `site/index.html`, set
   `window.KT_CONFIG = { server: 'https://kitty-toots.your-name.workers.dev' };`
2. Drag the `site` folder onto Netlify (Sites > Add new site > Deploy manually).

## 4. Lock the server to your site

In `worker/wrangler.toml`, set `ALLOWED_ORIGINS` to your Netlify address, for example
`"https://kittytoots.netlify.app"`. Then run `npx wrangler deploy` again.

Other websites can then no longer use your server or your TURN allowance.
Once the lock is on, opening `/turn` directly in a browser shows
"not allowed". That's expected.

## How voice chat behaves

- Voice is off until a player clicks the microphone button. The browser then
  asks for microphone permission.
- Push-to-talk is the default: hold **V** to talk. Click the button again for
  an always-on mic, and once more to switch voice off.
- Players only hear each other when both have voice switched on and are in the
  same garden. Voices get quieter with distance in the garden.
- Each friend can be muted from the "In this garden" list.
- A garden holds up to 8 players.
- Anyone who knows a garden name can join it. The start screen suggests a random
  name like `giggly-teapot-482`, so keep garden names private, like a party code.

## Trying the Worker on your computer

Run `npm run dev` in `worker/` and set `server` to `http://127.0.0.1:8787` in the
game while testing. Browsers only allow the microphone on `https` pages or on
`localhost`.
